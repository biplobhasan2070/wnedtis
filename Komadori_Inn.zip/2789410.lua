-- 2789410's Lua and Manifest Created by Hubcap Manifest
-- Komadori Inn
-- Created: October 25, 2026 at 18:38:59 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 26198325 (public branch)
-- Build Date: October 25, 2026 at 10:39:29 EDT (1792939169)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2789410, 1, "ff3f0af42d15e4b2c54727b454eabb59df0066dd8c4c734210337d3034a803bd") -- Komadori Inn
-- MAIN APP DEPOTS
addappid(2789411, 1, "97b924ef34e279d63dc59146e5eaba413da0367b332dd2db539303fc04dd5ef6") -- Depot 2789411
setManifestid(2789411, "6317279188051875031", 1164495309)