-- 4690300's Lua and Manifest Created by Hubcap Manifest
-- Slave Princess Elnea
-- Created: October 24, 2026 at 16:35:08 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 26185621 (public branch)
-- Build Date: October 24, 2026 at 13:28:07 EDT (1792862887)
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4690300) -- Slave Princess Elnea
-- MAIN APP DEPOTS
addappid(4690301, 1, "b4a66a1dd04479497247c4db441c1396a419a923e5a590bc26fb0c9182e34850") -- Depot 4690301
setManifestid(4690301, "5515351567656358374", 2864189937)
addappid(4690302, 1, "4b645d70603296206c7b723698958379173809e739e7af2259321de6f92e51a0") -- Depot 4690302
setManifestid(4690302, "81857574384609590", 2864378502)
addappid(4690303, 1, "c183062d278797f81ec70f5565682969876146505f9ab0ec7196ada98dc98f26") -- Depot 4690303
setManifestid(4690303, "343784745340675394", 2874658077)
addappid(4690304, 1, "cba22c8f082f24a7cb24358055d478ece9b43af948364e998a1d06387d5f3ef5") -- Depot 4690304
setManifestid(4690304, "1727071626854355837", 2870972948)