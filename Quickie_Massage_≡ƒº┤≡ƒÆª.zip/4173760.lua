-- 4173760's Lua and Manifest Created by Hubcap Manifest
-- Quickie Massage 🧴💦
-- Created: October 25, 2026 at 17:15:25 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 21619266 (public branch)
-- Build Date: January 23, 2026 at 08:51:41 EST (1769176301)
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4173760) -- Quickie Massage 🧴💦
-- MAIN APP DEPOTS
addappid(4173761, 1, "e53d2e9fed3469120a75b78397c871a44f989ade1369e98447bab79337da1c89") -- Depot 4173761
setManifestid(4173761, "1273512792044991524", 2619643834)
addappid(4173762, 1, "f187045dd4a4ecad213f53225e236eedc6c9b24fe2bfc4e81c80bb1784913308") -- Depot 4173762
setManifestid(4173762, "470369481022036205", 2636178017)
addappid(4173763, 1, "1f77a88b0fddaf8b37a3d0f8176a3afb9df7797b88e9ce4041d37d372bed49fc") -- Depot 4173763
setManifestid(4173763, "8777681645875719344", 2617891280)