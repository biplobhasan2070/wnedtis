-- 3929330's Lua and Manifest Created by Hubcap Manifest
-- Relief
-- Created: October 25, 2026 at 16:39:22 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 25949584 (public branch)
-- Build Date: October 14, 2026 at 22:34:27 EDT (1792031667)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(3929330) -- Relief
-- MAIN APP DEPOTS
addappid(3929331, 1, "17ded237a6fb72f1fbc3a819e4a05690e49ca77c2f2bdc585ba578ffcd7056e5") -- Depot 3929331
setManifestid(3929331, "1524886701540270908", 3291259453)