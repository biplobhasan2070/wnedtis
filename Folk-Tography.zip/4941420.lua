-- 4941420's Lua and Manifest Created by Hubcap Manifest
-- Folk-Tography
-- Created: October 25, 2026 at 01:12:22 EDT
-- Website: https://hubcapmanifest.com/
-- Build: 26124200 (public branch)
-- Build Date: October 21, 2026 at 23:45:55 EDT (1792640755)
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(4941420, 1, "36752badcf80fd0bb3beb919a6cca1ac56e0abe673fd329a89f35e849dffc2d7") -- Folk-Tography
-- MAIN APP DEPOTS
addappid(4941421, 1, "16fd13259cb6507bb437b445d9c3610614d072107bc292146d1d32f81e068ed7") -- Depot 4941421
setManifestid(4941421, "1008947989042823314", 1796610465)